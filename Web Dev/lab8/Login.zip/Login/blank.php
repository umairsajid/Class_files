<!doctype html>
<html ng-app>
<div ng-controller="MyCtrl">
<head
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 8</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="lab8.css">  
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> 
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.27/angular.min.js"></script>
    <script src="lab8.js" type="text/javascript"></script>  
</head>
<body>
  <div class="container" >
    <div ng-controller="MyCtrl">
      <div class="row">
      </div>
    </div>
  </div>    
</body>
</html>
