#http://docs.python.org/2/library/exceptions.html
import math
def main():
	try:
		a,b=-45,0
		#print a/b
		#print math.sqrt(a)
		#raise NameError('Unknown error')
		
	except ArithmeticError:
		print "ArithmeticError"			
	except ZeroDivisionError as z:
		print "Divide by zero - ", z
	except (ValueError,IOError):
		print "SQRT of negative number or an IO error"
	except:
		print "Any other exception"
	else:
		print "No exceptions encountered"
	finally:
		print "Always executed"

if __name__=="__main__":   #note this style!
	main()