def main():
	#lists()
	dictionaries()
	#list_comprehension()

def lists():
	#Lists
	print [1,2] + [3,4]
	print [1,2] * 3
	
	list=['A','B','C','D','F']
	print list[0]
	print list[3:]
	print len(list)
	
	list = [1,"blah",4, 'U']
	print list
	print 4 in list
	print "blah" in list
	list[2]="four"
	print 4 in list
	
	list = []
	list.append(10)
	list.append(20)
	list.append(25)
	list.append(23)
	print list
	
	list.sort()
	print list
	
	list.reverse()
	print list
	
	print list.index(25)
	list.remove(25)	
	list.insert(2,20)
	print list.count(20)
	print list
	del list[2] # built in operator
	print list

	print #Multi dimensional arrays
	table = [ [3], [1,2,3], [6,7] ]
	for i in range(len(table)):
		for j in range(len(table[i])):
			print table[i][j],
		print
		
	print
	tuples =(22,17,6,5)
	for tuple in tuples:
		print tuple
		
	#tuple[0]=20 #FAILS!

	#sets
	list=['A','A','A','B','C']
	list2 = set(list)
	print (list2)

def dictionaries():
	fruits = { "orange":"orange", "banana":"yellow", "apple":"red" }
	print fruits["banana"]
	
	
	print fruits.has_key("apple")
	print "apple" in fruits
	
	print fruits.keys()
	print fruits.values()
	print fruits.items()
	for item in fruits.items(): #Note that these are tuples!
		print item
		print item[0],"-->",item[1]
	
	#print fruits["strawberry"]  #FAILS!
	print fruits.get("strawberry","pink")
	print fruits.get("banana","pink")
	
	del fruits["orange"]
	print fruits
	
	print
	fruits = {}
	fruits["grapes"] = "purple"
	print fruits
	
def list_comprehension():	
	#set notation: {w | w \in V and P(w) }
	#python equivalent: [w for w in V if P(w)]
	
	V = ['a','ab','abc','abcd','abcde', 'abcdef']
	W = [ w for w in V if len(w) > 3 ]
	print W
	
	W = [ w for w in V if len(w) > 3 and len(w) < 6]
	print W
	
	W = [len(w) for w in V]
	print W
	
	W = [ w.upper() for w in V if len(w) > 3 and len(w) < 6]
	print W
	
	W = [[w.upper(), w.lower(), len(w)] for w in V]
	print W
	
	V = [w for w in range(21)]
	W = [w for w in V if w % 2 == 0]
	print W
	
#Call the main method
main()