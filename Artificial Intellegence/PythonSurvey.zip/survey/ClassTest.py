from Classes import Animal,Bird, Cat, Dog

def cmpAnimals(a1,a2):
	return cmp(a1.getName(),a2.getName())
	
def main():
	a1 = Animal("Jonny",2)
	a2 = Animal("Spidey",8)
	b1 = Bird("Donald")
	b2 = Bird("Taffy")
	d1 = Dog("Fido")
	d2 = Dog("Goofy")
	c1 = Cat("Tabby")
	c2 = Cat("Fluffy")
	
	print isinstance(d2,Animal)
	print isinstance(d2,Dog)
	print isinstance(c2,Dog)
	print isinstance(a2,Dog)
	
	animals =[a1,a2,b1,b2,c1,c2,d1,d2]
	
	print "Animals in category:",Animal.getCategory()
	
	for a in animals:
		a.makeSound()
	
	animals.sort()
	for a in animals:
			print a.getName(),a.getLegs() 
	
	print
	
	animals.sort(cmpAnimals)
	for a in animals:
			print a.name,a.legs #note visibility!
	

if __name__=="__main__":
	main()