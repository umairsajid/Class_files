"""Classes.py
Provides examples of python classes."""

class Animal:
	""" Models a generic animal"""
	category="land animals" #class variable
	def __init__(self, name, legs):
		self.name = name	#instance variables
		self.legs = legs
		
	def getName(self): #do we need these accessors?
		return self.name
		
	def getLegs(self):
		return self.legs

	def makeSound(self):
		print "Animal",self.name,"makes unknown sound"
	
	@staticmethod	#note decorator! 
	def getCategory():
		return Animal.category

class Bird(Animal):
	""" Models a bird"""
	def __init__(self, name):
		Animal.__init__(self,name,2)
		
	def makeSound(self):
		print "Bird",self.name,"tweets"

class Dog(Animal):
	""" Models a dog"""
	def __init__(self, name):
		Animal.__init__(self,name,4)
		
	def makeSound(self):
		print "Dog",self.name,"barks"

class Cat(Animal):
	""" Models a cat"""
	def __init__(self, name):
		Animal.__init__(self,name,4)
		
	def makeSound(self):
		print "Cat",self.name,"meows"



