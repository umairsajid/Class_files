# A short "structured programming" tour of the python language
import math
import string
def main():
	'''
	basic()
			
	
	inputs()
	
	x,y = loops() # returning multiple values from a function
	print y,x	
	
	strings()
	'''
	files()
	
	
def basic():	
	print int(4.5),round(3.6),math.sqrt(4.2)
	print int("4"),float("4.5")
	print "This is the way to print a formatted string - %s , an int - %d and a float - %5.2f" % ("abc",22, 2345.514)
	print 4,
	print 5
	print	
	
	#exponentiation operator
	print "2^5.1 is",2**(5.1)
	

	#Simultaneous assignment
	x,y = 5,100
	print x,y
	x,y = y,x
	print x,y

def inputs():
	#Input, passing parameters and returning values from functions
	celsius = input("Enter celsius temp: ")
	fahrenheit = ifs(celsius)	
	print "The temp. is", fahrenheit,"degrees fahrenheit"	

def ifs(celsius):
	fahrenheit = (9.0/5.0) * celsius + 32
		
	if fahrenheit > 90:
		print "Very Hot!"
	elif fahrenheit < 30:
		print "Brrr"
	else:
		print "Mehh..."
		
	#Relational and logical operators or, not, and , == != >= <=
	x,y=50,100
	if ((x==50 and y !=100) or  (x<=50 and y>=100) or not(True)):
		print "Success"
	return fahrenheit

def loops():
	#Loops
	for i in range(10):
		x = i * 2
		print i,x
	
	print range(5) 
	
	for i in [0,1,12,22,23,4]:
		print i
	
	print
	y=5
	for i in range(y,1,-1):
		print i
			
	i=0
	while i<=10:
		print i
		i+=1
		
	return 17,"Hello"

def strings():
	#Strings
	#str = input("Enter a string: ")
	#print str
	
	str = raw_input("Enter another string: ")
	print str
	
	str = "Hello"
	print str[0],str[4],str[-1]
	
	#str[0]="X" #NOTE THAT THIS FAILS!

	print str[0:4]
	print str[3:],str[:3],str[:]
	
	print len(str)
	print str + str
	print str * 3	
	for ch in str:
		print ch,
	print
	#String methods, require the string library
	str = "cat sat on the mat"
	print string.upper(str)
	print string.lower("HELLO")
	print string.replace(str, "at","XYZ")
	print string.count(str,"a")
	print string.find(str,"a")
	
	array = string.split(str)
	print array
	print string.join(array)
	

def files():
	#Files
	infile = open("inp.dat","r")
	outfile = open("out.dat", "w")
	
	#method 1: read as a single string
	data = infile.read()
	print data
	outfile.write(data)
	
	'''
	#method 2: return list of remaining lines
	for line in infile.readlines():
		print line[:-1]
	        outfile.write(line)

	#method 3: process lines one at a time
	for line in infile:
		print line[:-1]
		outfile.write(line)
	
	#method 4: process lines one at a time using 
	line = infile.readline()
	while line != "":
		print line[:-1]
		outfile.write(line)
		line = infile.readline()
	'''	
	
	infile.close()
	outfile.close()

#Call the main method
main()