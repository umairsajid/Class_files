#The Hello World Program
def main():	
	print "Hello World"


#Call the main method
main()