Question 1:

Yes

The agent starts by taking the path of least resistance until it discovers an outside wall.  Once the wall is found, the agent traces the outside wall until it discovers the path that led wall.  The agent does not cross one of its previous paths unless it has no option but to.  In all phases the the agents first choice is to go right.  The agent will only go left if right is blocked either by an obstacle or a previous path.  This is so that the current area it is working on is surveyed as completely as possible prior to moving on the next area.  If the agent finds itself surrounded by obstacles or paths that it had previously made it goes straight until it has no choice then makes a random turn to find an undiscovered path.

Table 	Average Score
L1		504
L2		115
L3		93
L4		150
L5		320

Question 2:

Yes

Question 3:

Yes 
