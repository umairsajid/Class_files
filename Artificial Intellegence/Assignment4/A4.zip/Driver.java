import java.io.*;

class Driver
{
    public static void main(String[] args)
    {
        DataSet training_data = new DataSet( args[0] + ".training");
        
        ANN nn=null;
        // YOU MUST PROVIDE THE CORRECT WEIGHTS FOR ALPHA AND BETA
        // PART 3
        if (args[0].equalsIgnoreCase("and"))
        {
            nn = new ANN(2,2,1);// you may NOT change these values for this part
    
            nn.train( 0.0 , 0.0 ,  /* you must choose good values for these */
    		 0.00001,10000000,
    		 10000,
    		 training_data.get_inputs(),training_data.get_outputs(),
    		 null, null, null);

        }
        else if (args[0].equalsIgnoreCase("or"))
        {
            nn = new ANN(2,2,1);// you may NOT change these values for this part
    
            nn.train( 0.0 , 0.0 ,  /* you must choose good values for these */
    		 0.00001,10000000,
    		 10000,
    		 training_data.get_inputs(),training_data.get_outputs(),
    		 null, null, null);
        }
        else if (args[0].equalsIgnoreCase("xor"))
        {
            nn = new ANN(2,2,1);// you may NOT change these values for this part
    
            nn.train( 0.0 , 0.0 ,  /* you must choose good values for these */
    		 0.00001,10000000,
    		 10000,
    		 training_data.get_inputs(),training_data.get_outputs(),
    		 null, null, null);
        }

   
        System.out.format("After %d epochs, error = %7.5f\n",
                  nn.get_last_epoch(),nn.get_last_error());
    
    }// main class

}// Driver class
