import java.util.*;
import java.text.*;
import java.io.*;

class ANN
{
    /* number of input units */
    private int n_inputs;

    /* number of hidden units */
    private int n_hidden;

    /* number of output units */
    private int n_outputs;

    /* weights from input layer to hidden layer */
    private double[][] IH;

    /* weights from hidden layer to output layer */
    private double[][] HW;

    /* current values of weight changes from input layer to hidden layer */
    private double[][] delta_IH;

    /* previous values of weight changes from input layer to hidden layer */
    private double[][] previous_delta_IH;

    /* current values of weight changes from hidden layer to output layer */
    private double[][] delta_HW;

    /* previous values of weight changes from hidden layer to output layer */
    private double[][] previous_delta_HW;

    /* learning rate */
    private double alpha;

    /* momentum */
    private double beta;

    /* filename for training data */
    private String training_file;

    /* inputs of training set cases */
    private double[][] training_inputs;

    /* outputs of training set cases */
    private double[][] training_outputs;

    /* hidden values */
    private double[] hidden_values;

    /* error vector for hidden layer */
    private double[] hidden_errors;

    /* output values */
    private double[] output_values;

    /* error vector for output layer */
    private double[] output_errors;

    /* maximum number of training epochs */
    private int max_epochs;

    /* number of last training epoch */
    private int last_epoch;

    /* target error */
    private double training_error;

    /* value of the error at the end of training */
    private double last_error;

    /* random number generator */
    private Random random;

    ANN(int n_inputs, int n_hidden, int n_outputs)
    {
        random = new Random();

        this.n_inputs = n_inputs;
        this.n_hidden = n_hidden;
        this.n_outputs = n_outputs;
        IH = new double[n_inputs+1][n_hidden];
        previous_delta_IH = new double[n_inputs+1][n_hidden];
        delta_IH = new double[n_inputs+1][n_hidden];
        assign_random_weights(IH);
        hidden_values = new double[n_hidden];
        hidden_errors = new double[n_hidden];

        HW = new double[n_hidden+1][n_outputs];
        previous_delta_HW = new double[n_hidden+1][n_outputs];
        delta_HW = new double[n_hidden+1][n_outputs];
        assign_random_weights(HW);
        output_values = new double[n_outputs];
        output_errors = new double[n_outputs];

    }// constructor

    public int get_last_epoch()
    {
        return last_epoch;
    }// get_last_epoch method

    public double get_last_error()
    {
        return last_error;
    }// get_last_error method

    public double train(double alpha, double beta,
            double training_error, int max_epochs,
            int report,
            double[][] training_inputs, double[][] training_outputs,
            double[][] testing_inputs, double[][] testing_outputs,
            PrintWriter learning_data_file)
    {
        double error = 0.0;
        double testing_error = 0.0;

        assign_random_weights(IH);
        assign_random_weights(HW);
        init_previous_delta_w();

        this.alpha = alpha;
        this.beta = beta;
        this.training_error = training_error;
        this.max_epochs = max_epochs;
        this.training_inputs = training_inputs;
        this.training_outputs = training_outputs;

        double[] actual;
        for(int epoch=0; epoch<max_epochs; epoch++)
        {
            reinit_delta_w();
            error = 0.0;
            int num_correct = 0;
            int num_correct_test = 0;

            /* t = index of training case*/
            for(int t=0; t<training_inputs.length; t++)
            {
                // compute actual output
                actual = forward_feed( training_inputs[t] );

                // compute error for this training example
                double t_error = 0.0;
                for(int o=0; o<n_outputs; o++)
                    t_error +=
                    (training_outputs[t][o] - actual[o]) *
                        (training_outputs[t][o] - actual[o]);

                /* accumulate error */
                error += t_error / 2;

                // compute output layer errors
                for(int o=0; o<n_outputs; o++)
                    output_errors[o] =
                        (training_outputs[t][o] - actual[o]) *
                          actual[o] * (1.0 - actual[o]);

                // compute hidden layer errors
                for(int h=0; h<n_hidden; h++)
                {
                    double delta_h = 0;
                    for(int o=0; o<n_outputs; o++)
                        delta_h += HW[h][o] * output_errors[o];
                        hidden_errors[h] =
                            delta_h * hidden_values[h] * (1.0 - hidden_values[h]);
                }

                // compute weight changes for first matrix: input -> hidden
                for(int i=0; i<n_inputs; i++)
                    for(int h=0; h<n_hidden; h++)
                        delta_IH[i][h] +=
                            alpha * training_inputs[t][i] * hidden_errors[h];
                int bias_row = IH.length-1;
                for(int h=0; h<n_hidden; h++)
                    delta_IH[bias_row][h] += -alpha * hidden_errors[h];

                // compute weight changes for second matrix: hidden -> output
                //YOU MUST PROVIDE THE CODE FOR THIS, VERY SIMILAR TO THE PRECEDING BLOCK
                //PART 2

            }// loop over the training set


            error /= training_inputs.length;

            if (epoch % report == 0)
            {

                DecimalFormat formatter = new DecimalFormat("#.##########");
                String error_str = formatter.format(error);
                String test_error_str = formatter.format(testing_error);

                System.out.format( epoch + "," + error_str + " " + num_correct
                           + "," +  test_error_str + " " +
                           num_correct_test + "\n");
            }

            if (error < training_error)
            {
                last_error = error;
                last_epoch = epoch;
                return error;
            }

            // update the weights at the end of the epoch
            for(int i=0; i<=n_inputs; i++)
                for(int h=0; h<n_hidden; h++)
                {
                    IH[i][h] +=
                        (1.0 - beta) * delta_IH[i][h] +
                        beta * previous_delta_IH[i][h];
                    previous_delta_IH[i][h] = delta_IH[i][h];
                }

            for(int h=0; h<=n_hidden; h++)
                for(int o=0; o<n_outputs; o++)
                {
                    HW[h][o] +=
                        (1.0 - beta) * delta_HW[h][o] +
                        beta * previous_delta_HW[h][o];
                    previous_delta_HW[h][o] = delta_HW[h][o];;
                }
        }

        last_error = error;
        last_epoch = max_epochs;

        return error;
    }// train method


    private void assign_random_weights(double[][] a)
    {

        for(int i=0; i<a.length; i++)
            for(int j=0; j<a[0].length; j++)
            a[i][j] = (random.nextBoolean() ? -1 : 1) *
                0.1 * random.nextDouble();
    }// assign_random_weights method


    private void init_previous_delta_w()
    {
        for(int i=0; i<=n_inputs; i++)
            for(int h=0; h<n_hidden; h++)
                previous_delta_IH[i][h] = 0.0;

        for(int h=0; h<=n_hidden; h++)
            for(int o=0; o<n_outputs; o++)
                previous_delta_HW[h][o] = 0.0;
    }// init_previous_delta_w method

    private void reinit_delta_w()
    {
        for(int i=0; i<=n_inputs; i++)
            for(int h=0; h<n_hidden; h++)
                delta_IH[i][h] = 0.0;

        for(int h=0; h<=n_hidden; h++)
            for(int o=0; o<n_outputs; o++)
                delta_HW[h][o] = 0.0;
    }// reinit_delta_w method

    private double[] forward_feed(double[] inputs)
    {
        int bias_row = IH.length-1;
        // first compute the hidden values
        // YOU MUST PROVIDE THE CODE FOR THIS
        // PART 1
        //...

        bias_row = HW.length-1;
        // then compute the final outputs
        // YOU MUST PROVIDE THE CODE FOR THIS
        // PART 1
        //...

        return output_values;
    }// forward_feed method

    private static double sigmoid(double x)
    {
        return 1.0 / (1.0 + Math.exp(-x) );
    }// sigmoid method

}// ANN class
