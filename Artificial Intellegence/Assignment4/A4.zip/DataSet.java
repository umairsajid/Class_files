import java.util.Scanner;
import java.io.*;

class DataSet
{
    private int num_data;
    private int num_inputs;
    private int num_outputs;
    private double[][] inputs;
    private double[][] outputs;
    private String filename;

    DataSet(String filename)
    {
    	this.filename = filename;
    	load_from_file();
    }// constructor

    public double[][] get_inputs()
    {
    	return inputs;
    }// get_inputs method

    public double[][] get_outputs()
    {
    	return outputs;
    }// get_outputs method

    private void load_from_file()
    {
    	Scanner file = null; 
    	try {
    	    file = new Scanner( new File( filename ) );
    	} catch (FileNotFoundException e)
    	{
    	    System.out.println("Could not open file: " + filename);
    	    System.exit(1);
    	}

    	num_data = file.nextInt();
    	num_inputs = file.nextInt();
    	num_outputs = file.nextInt();
    	   
    	String line = file.nextLine(); // skip the rest of the line
    
    	inputs = new double[num_data][num_inputs];
    	outputs = new double[num_data][num_outputs];
    	int data_point = 0;
    	while (file.hasNextDouble())
    	{
    	    for(int i=0; i<num_inputs; i++)
    		inputs[data_point][i] = file.nextDouble();
    
    	    for(int i=0; i<num_outputs; i++)
    		outputs[data_point][i] = file.nextDouble();
    
    	    data_point++;
    	    //System.out.println(data[0] + "//" + data[1]);
    	}
    }// load_from_file method

}// DataSet class
